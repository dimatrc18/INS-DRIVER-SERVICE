<?php
// 1) DATABASE SETTINGS – CHANGE THESE TO YOUR VALUES
$servername = "localhost";          // usually localhost on Hostinger
$username   = "Igor_2004";
$password   = "Igrik123452004%$";
$dbname     = "DOROGO_Bookings";

// CORS Headers (Allows your React frontend to talk to this script if on different origins during testing)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// 2) CONNECT TO MYSQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    die("Connection failed: " . $conn->connect_error);
}

// 3) READ FORM DATA (NAMES MUST MATCH YOUR <input name="...">)
$full_name       = $_POST['full_name']       ?? '';
$phone           = $_POST['phone']           ?? '';
$email           = $_POST['email']           ?? '';
$service_type    = $_POST['service_type']    ?? '';
$pickup_location = $_POST['pickup_location'] ?? '';
$dropoff_location= $_POST['dropoff_location']?? '';
$date            = $_POST['date']            ?? '';
$time            = $_POST['time']            ?? '';
$passengers      = $_POST['passengers']      ?? 0;
$luggage         = $_POST['luggage']         ?? 0;
$vehicle         = $_POST['vehicle']         ?? '';
$message         = $_POST['message']         ?? '';

// 4) PREPARE SQL – USE A PREPARED STATEMENT (SAFER)
$stmt = $conn->prepare("
    INSERT INTO bookings 
    (full_name, phone, email, service_type, 
     pickup_location, dropoff_location, 
     date, time, passengers, luggage, 
     vehicle, message) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

// Check if prepare was successful
if ($stmt === false) {
    http_response_code(500);
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param(
    "ssssssssiiss",
    $full_name,
    $phone,
    $email,
    $service_type,
    $pickup_location,
    $dropoff_location,
    $date,
    $time,
    $passengers,
    $luggage,
    $vehicle,
    $message
);

// 5) EXECUTE AND GIVE SIMPLE RESPONSE
if ($stmt->execute()) {
    echo "Booking received. Thank you!";
} else {
    http_response_code(500);
    echo "Error while saving booking: " . $stmt->error;
}

// 6) CLEAN UP
$stmt->close();
$conn->close();
?>
